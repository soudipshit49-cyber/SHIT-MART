package com.shitmart.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity: AppCompatActivity() {
 private lateinit var content: TextView
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
  content=findViewById(R.id.content)
  findViewById<Button>(R.id.products).setOnClickListener { content.text="PRODUCTS\n\nMen • Women • Kids • Shoes • Gifts\n\nSample: Men's Hoodie — ₹799\nWomen's Top — ₹499\nSports Shoes — ₹1,299\nGift Box — ₹399" }
  findViewById<Button>(R.id.cart).setOnClickListener { content.text="CART\n\nYour cart will show products, quantity, subtotal and delivery charge." }
  findViewById<Button>(R.id.checkout).setOnClickListener { content.text="CHECKOUT\n\nAddress → Payment → Cash on Delivery (COD)\nOnline payment will be connected after the real payment gateway is configured." }
  findViewById<Button>(R.id.orders).setOnClickListener { content.text="MY ORDERS\n\nPending → Confirmed → Shipped → Delivered" }
  findViewById<Button>(R.id.account).setOnClickListener { content.text="ACCOUNT\n\nLogin / Signup\nName\nEmail\nPhone\nDelivery Address" }
  findViewById<Button>(R.id.admin).setOnClickListener { content.text="ADMIN PANEL\n\nDashboard\nProduct Upload\nStock\nOrders\nCustomers\nSettings\n\nDemo admin credentials will be replaced by secure authentication in the backend phase." }
 }
}
