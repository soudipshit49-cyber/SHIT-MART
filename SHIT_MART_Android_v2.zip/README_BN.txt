SHIT MART Android v2
এই ভার্সনে Customer App-এর প্রধান flow-এর UI structure যোগ করা হয়েছে:
Products, Cart, Checkout/COD, Orders, Account এবং Admin Panel sections.

এটি এখনও production APK নয় এবং online database/payment নয়।
পরের ধাপে backend/database ও secure authentication যুক্ত করতে হবে।
